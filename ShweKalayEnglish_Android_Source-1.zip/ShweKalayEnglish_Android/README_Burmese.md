# ရွှေကလေး English — Android Source Project

ဒီ project သည် Android WebView wrapper + offline HTML lesson app ဖြစ်သည်။ Source code ကို Android Studio ဖြင့်ဖွင့်ပြီး APK ထုတ်နိုင်ရန် ရည်ရွယ်ထားသည်။

## လက်ရှိပါဝင်သောအရာ
- A–Z သင်ခန်းစာနှင့် စကားလုံး ၂၆ လုံး
- English letter-name နှင့် word pronunciation WAV ဖိုင်များကို `app/src/main/assets/audio/en/` ထဲတွင်ထည့်ထားသည်
- ABC ရွေးချယ်ခြင်း၊ ပုံ/စကားလုံးတွဲဖော်ပြခြင်း၊ အက္ခရာ Quiz
- ကြယ်ပွင့်နှင့် သင်ယူမှုမှတ်တမ်းကို localStorage ထဲတွင် သိမ်းဆည်းခြင်း
- မိဘအပိုင်းကို အလွယ်တွက်ချက်မေးခွန်းဖြင့် ဖွင့်ခြင်း
- Android TextToSpeech မှ မြန်မာဘာသာကို ရနိုင်ပါက အသုံးပြုရန် ကြိုးစားခြင်း
- INTERNET permission မပါ၊ ကြော်ငြာမပါ၊ account မလို

## အရေးကြီးသော ကန့်သတ်ချက်
**ဒီ source project ထဲမှာ စစ်မှန်သော မြန်မာအသံဖိုင်များ မပါသေးပါ။** Android စက်တွင် မြန်မာ TTS voice ထည့်သွင်းထားပါက မြန်မာစာကို ဖတ်ပေးနိုင်သော်လည်း ဖုန်းအများစုတွင် အာမခံမရပါ။ ရောင်းချမည့် offline product အတွက် မြန်မာ native speaker ဖြင့် အက္ခရာ/အဓိပ္ပာယ်အသံဖိုင်များကို မှတ်တမ်းတင်ပြီး app assets ထဲသို့ ထည့်သွင်းရန် လိုအပ်သည်။ မစမ်းသပ်ရသေးသော APK ကို ရောင်းချရန် မသုံးပါနှင့်။

## Android Studio မှ APK ထုတ်ရန်
1. Android Studio ကို ကွန်ပျူတာတွင် ထည့်သွင်းပါ။
2. `ShweKalayEnglish` project folder ကို Open လုပ်ပါ။
3. Gradle Sync ပြီးအောင်စောင့်ပါ။ Android SDK Platform 35 ကို install လုပ်ရန် လိုအပ်နိုင်သည်။
4. ဖုန်းကို USB debugging ဖြင့်ချိတ်ပြီး Run ကိုနှိပ်ကာ စမ်းသပ်ပါ။
5. Debug APK စမ်းထုတ်ရန်: **Build > Build Bundle(s) / APK(s) > Build APK(s)**။
6. ရောင်းချရန် release build ထုတ်မည်ဆိုပါက **Build > Generate Signed Bundle / APK** ကိုရွေးပြီး ကိုယ်ပိုင် keystore ကိုဖန်တီးပါ။ Keystore နဲ့ password ကို လုံခြုံစွာ backup ထားပါ။ ပျောက်ဆုံးလျှင် update ထုတ်ရာတွင် ပြဿနာဖြစ်နိုင်သည်။

## တစ်ကြိမ်ဝယ်ယူပြီး အမြဲသုံးနိုင်သည့်ရောင်းချမှုပုံစံ
လွယ်ကူဆုံးနည်းမှာ Google Play Store တွင် app ကို **paid app** အဖြစ် စာရင်းတင်ခြင်းဖြစ်သည်။ မိဘက တစ်ကြိမ်ဝယ်ယူပြီး ထို Google account ဖြင့် ပြန်ဒေါင်းလုဒ်လုပ်နိုင်သည်။ Play Console developer account၊ app icon၊ screenshots၊ privacy policy၊ content rating၊ target audience နှင့် Google Play Families ဆိုင်ရာ စည်းမျဉ်းများကို ပြည့်စုံစေရန် လိုအပ်သည်။ Play Store တင်ရန် APK ထက် Android App Bundle (AAB) ကို အသုံးပြုရနိုင်သည်။

APK ကို တိုက်ရိုက်ရောင်းချလိုပါက payment/activation ကို ကိုယ်တိုင်စီမံရမည်။ Local-only unlock ကို ပြုပြင်ဖောက်ထွင်းနိုင်သောကြောင့် လုံခြုံသော payment verification ဟု မယူဆသင့်ပါ။ Google Play in-app one-time product ရောင်းချမည်ဆိုပါက Play Billing နှင့် server-side purchase verification ကို ထပ်မံထည့်သွင်းရမည်။

## ကလေးလုံခြုံရေးအတွက် မဖြစ်မနေစစ်ရန်
- အသက် ၃–၆ အရွယ်ကလေးများအတွက် အရွယ်နှင့်သင့်လျော်မှု၊ အသံ/ပုံပိုင်ဆိုင်ခွင့်နှင့် accessibility ကို စမ်းသပ်ပါ။
- ကြော်ငြာ၊ analytics သို့မဟုတ် ကလေးကို ခွဲခြားသတ်မှတ်နိုင်သည့် data မထည့်ပါနှင့်။
- မိဘဂိတ်သည် ရိုးရှင်းသောအတားအဆီးသာဖြစ်ပြီး လုံခြုံရေးအပြည့်အဝ မဟုတ်ပါ။
- စျေးနှုန်း၊ refund၊ privacy policy နှင့် customer support ကို ရှင်းလင်းစွာ ဖော်ပြပါ။
- Google Play Families Policy နှင့် သက်ဆိုင်ရာဥပဒေများကို ထုတ်ဝေမီစစ်ဆေးပါ။

## အသံဖိုင်များ
English အသံဖိုင်များကို development environment ရှိ `espeak` ဖြင့် ဖန်တီးထားသည်။ ထုတ်ဝေမီ native English speaker သို့မဟုတ် သင့်တော်သော အသံဖိုင်များဖြင့် အရည်အသွေးစစ်ဆေးရန် အကြံပြုသည်။ မြန်မာအသံဖိုင်များကို သီးခြားထည့်သွင်းရပါမည်။


## APK ကို Android ဖုန်းတစ်လုံးတည်းနဲ့ Cloud မှ Build လုပ်ရန် (အခမဲ့စတင်နိုင်သောနည်း)
ဒီ project မှာ `.github/workflows/android-build.yml` workflow ကို ထည့်ထားသည်။ GitHub က cloud runner ပေါ်တွင် debug APK တည်ဆောက်ပြီး artifact အဖြစ် ထုတ်ပေးရန် ရည်ရွယ်သည်။

1. GitHub account တစ်ခုဖြင့် sign in လုပ်ပါ။ Repository အသစ်တစ်ခုဖန်တီးပြီး ဒီ ZIP ကို Extract လုပ်ထားသော project ဖိုင်များကို repository ထဲသို့ upload လုပ်ပါ။ `.github/workflows/android-build.yml` ဖိုင်လည်း တင်ထားကြောင်း စစ်ပါ။
2. Repository ၏ **Actions** tab ကိုဖွင့်ပါ။
3. `Build Shwe Kalay English APK` workflow ကို ရွေးပြီး **Run workflow** ကိုနှိပ်ပါ။ (workflow ဖိုင်ကို default branch ထဲသို့ အရင် commit/push လုပ်ထားရမည်။)
4. Build အောင်မြင်ပါက workflow run စာမျက်နှာအောက်ပိုင်းရှိ **Artifacts** မှ `shwe-kalay-english-debug-apk` ကို download လုပ်ပါ။ ZIP ကို ဖုန်းမှာ Extract လုပ်ပြီး `app-debug.apk` ကိုနှိပ်ကာ install လုပ်ပါ။
5. Android က unknown-source installation အတွက် ခွင့်ပြုချက်တောင်းပါက ကိုယ်ယုံကြည်တဲ့ build ဖိုင်ဖြစ်ကြောင်း စစ်ဆေးပြီးမှ ဆက်လုပ်ပါ။ မသိတဲ့သူပေးသော APK များကို မတပ်ဆင်ပါနှင့်။

မှတ်ချက်များ:
- Cloud build အတွက် အင်တာနက်လိုသည်။ App ကို တပ်ဆင်ပြီးနောက် သင်ခန်းစာ assets များက offline ဖြစ်ရန် ရည်ရွယ်ထားသည်။
- GitHub Actions usage limits/quotas နှင့် account/repository policy များ သက်ရောက်နိုင်သည်။ အခမဲ့အမြဲရမည်ဟု အာမမခံနိုင်ပါ။
- ဒီ workflow သည် debug APK ကို ထုတ်ပေးသည်။ Debug APK ကို စမ်းသပ်ရန်သာ သုံးပါ။ အများပြည်သူသို့ ရောင်းချရန် release signing, testing, privacy policy, store compliance နှင့် ကလေးလုံခြုံရေး review ကို သီးခြားလုပ်ဆောင်ရမည်။
- ဒီ workflow ကို ဒီနေရာမှာ cloud ပေါ်တွင် run မထားသေးသဖြင့် build အောင်မြင်မှုကို အတည်မပြုရသေးပါ။
