English WAV files are bundled under audio/en.
For offline Burmese voice recordings, record licensed files and add them under audio/my/.
Suggested future filenames: meaning_apple.wav, meaning_ball.wav, ... then update index.html to play these files first.
Do not ship blank or placeholder recordings as finished content.
